package com.example.myberita

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    companion object{
        val INTENT_PARCELABLE = "OBJECT_INTENT"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

//untuk menampilkan sebuah gambar / judul berita / isi dari berita
        val beritaList = listOf<Berita>(
            Berita(R.drawable.bocahh,
                "Bocah Pengacung Jari Tengah Makin Terkenal, Follower Facebook Capai 100 Ribu dan Jadi Bintang Endorse",
                "Bocah yang mengacungkan jari tengah saat dibonceng sang emak kini makin terkenal karena sering dijadikan video parodi. Bocah asal Thailand bernama Im Kamaludin berhasil mengumpulkan lebih dari 100 ribu follower di Facebook.\n" +
                        "\n" +
                        "Jumlah follower dari bocah yang disebut buronan internasional ini mencapai 111.825 orang.\n" +
                        "\n" +
                        "Penggemarnya tak hanya dari Thailand. Sebagian besar penggemar lain datang dari Indonesia dan Malaysia.\n" +
                        "\n" +
                        "Selain itu, Im Kamaludin saat ini bahkan memperoleh pekerjaan untuk mempromosikan produk. Ia mendapat banyak endorse dan berkolaborasi dengan akun influencer lain. " +
                        "Bocah yang disebut buronan internasional ini bahkan pernah viral ketika masuk ke toko HP dan turut mempromosikan produk secara tersirat." +
                        "Pengelola fanspage menyampaikan rasa terima kasih kepada para penggemar yang menyukai Im Kamaludin."
            ),
            Berita(R.drawable.perselikuhan,
                "Auto Jadi Sultan! Wanita Lelang Barang Branded Milik Suaminya yang Selingkuh, Sampai Dapat 83 Juta Lebih",
                "Pernikahan memang penuh dengan pasang dan surut. Tak selalu bahagia, beberapa pasangan harus melalui ujian, termasuk berupa perselingkuhan.\n" +
                        "\n" +
                        "Jamille Margarita Galvez, seorang wanita asal Filipina, sayangnya menjadi salah satu orang yang harus mengalami hal itu. Pernikahannya terpaksa kandas karena suaminya ketahuan memiliki hubungan dengan orang lain.\n" +
                        "\n" +
                        "Padahal dari pernikahan tersebut mereka sudah dikaruniai tiga orang anak. Namun kesalahan besar suaminya membuat Jamille bergegas mengakhiri pernikahan mereka.\n" +
                        "\n" +
                        "Belakangan sosok Jamille turut menjadi buah bibir warganet karena aksi tak biasa yang dilakukannya pasca mengetahui perselingkuhan suaminya. Pasalnya Jamille melelang barang-barang milik sang suami melalui sesi siaran langsung di Facebook-nya."
            ),
            Berita(R.drawable.kampung,
                "Info Takjil dan Buka Puasa di Jogja Lengkap dengan Menunya, Mahasiswa dan Anak Kos Merapat",
                "Seperti di bulan-bulan puasa sebelumnya, pada Ramadhan 1443 Hijriah saat ini, berbagai masjid di Jogja membagi-bagikan takjil secara gratis, begitupun makanan untuk buka puasa alias iftar. Tak ayal, selama Ramadan mahasiswa, khususnya anak kos, terkadang berburu info takjil dan buka puasa di Jogja.\n" +
                        "\n" +
                        "Pasalnya, umumnya mahasiswa yang merantau di Jogja dibatasi jatah pengeluarannya oleh orang tua, sehingga mereka harus berhemat, dan tak ada salahnya ikut kajian di masjid sembari mendapatkan takjil dan buka puasa bersama jemaah masjid.\n" +
                        "\n" +
                        "Beberapa masjid di Jogja sendiri telah merilis menu buka puasa lengkap selama satu bulan penuh Ramadhan. Salah satunya Masjid Jogokariyan, yang memang sangat terkenal dengan ikon Kampoeng Ramadhan Jogokariyan (KRJ).\n" +
                        "\n" +
                        "Menu makanannya pun tak main-main, yakni mulai dari tongseng ayam, bestik galantin, hingga empal gentong. Menu buka puasa bersama juga diunggah oleh masjid lainnya di Jogja."
            ),
            Berita(R.drawable.sekolah,
                "Pemkab Sleman Bersiap Gelar PTM 100 Persen untuk Semua Jenjang Pendidikan Usai Idulfitri",
                "Pemerintah Kabupaten Sleman bersiap menyelenggarakan pembelajaran tatap muka (PTM) 100 persen, untuk semua jenjang satuan pendidikan, setelah hari raya Idulfitri. \n" +
                        "Kepala Dinas Pendidikan Sleman Ery Widaryana mengatakan, dari hasil evaluasi yang dilakukan sementara ini, satuan pendidikan dalam kewenangan Pemkab Sleman dinilai siap melaksanakan PTM 100 persen.\n" +
                        "\"Namun, kami akan melihat dulu perkembangan situasi dan kondisi sepekan ini. Kalau situasi kondusif, tidak ada lagi kasus Covid-19 di sekolah, maka PTM 100 persen bisa dilangsungkan,\" terangnya. \n" +
                        "Ia menambahkan, secara umum PTM di Kabupaten Sleman masih berjalan 50 persen, karena status PPKM Kabupaten Sleman masih PPKM Level 3.\n" +
                        "Namun demikian, mengingat jumlah angka kasus yang perlahan menurun, saat ini Disdik sudah membolehkan kelas VI Sekolah Dasar dan kelas IX Sekolah Menengah Pertama, untuk PTM 100 persen.\n" +
                        "Dibolehkannya siswa kelas akhir mengikuti PTM 100 persen, mengingat mereka sedang mempersiapkan diri menghadapi ASPD.\n" +
                        "Pelaksanaan PTM bagi siswa kelas akhir, diminta tetap menerapkan protokol kesehatan dengan ketat, lanjutnya.\n" +
                        "Sekretaris Daerah Sleman Harda Kiswaya membenarkan perihal sudah adanya rencana dan kajian untuk menggelar PTM 100 persen."
            ),
            Berita(R.drawable.metafesbook,
                "Pengadilan Rusia Melarang Facebook dan Instagram karena Ekstremisme",
                "Pengadilan Rusia melarang Facebook dan Instagram. Keputusan pengadilan muncul sebagai tanggapan atas keputusan Meta untuk sementara mengizinkan seruan kekerasan terhadap militer Rusia oleh pengguna di Ukraina di tengah operasi militer Rusia.\n" +
                        "Meski dua platform Meta itu dilarang, aplikasi perpesanan WhatsApp milik perusahaan itu tetap diizinkan terus beroperasi di Rusia. \n" +
                        "Pengadilan distrik Tverskoy di Moskow, Rusia telah selesai meninjau dakwaan terhadap platform Facebook dan Instagram Meta serta memutuskan melarang keduanya di wilayah Rusia atas \"kegiatan ekstremis\".\n" +
                        "Pengadilan menyatakan keputusan itu akan segera berlaku, meskipun pengawas komunikasi Rusia Roskomnadzor telah mulai memblokir dua platform media sosial itu."
            ),
            Berita(R.drawable.facebook,
                "Facebook Siap Kunci Akun yang Belum Aktifkan Fitur Protect",
                "Awal Maret kemarin, sekelompok pengguna Facebook mendapat email misterius seperti spam berjudul \"Akun Anda memerlukan keamanan tingkat lanjut dari Facebook Protect\". \n" +
                        "Mereka diminta untuk mengaktifkan fitur Facebook Protect yang dapat mereka lakukan dengan menekan tombol tautan di email sebelum tanggal tertentu atau akun mereka akan dikunci.\n" +
                        "Facebook pun telah mengkonfirmasi bahwa itu memang merupakan program perusahaan untuk meningkatkan keamananan akun agar tidah mudah dibobol oleh para peretas. \n" +
                        "Program ini berlaku untuk sekelompok pengguna yang mungkin jadi target peretas, seperti pembela hak asasi manusia, jurnalis, dan pejabat pemerintah.\n" +
                        "Sayang, email yang dikirim Facebook dari alamat security@facebookmail.com itu menyerupai email spam yang biasa dijumpai sehingga banyak pengguna yang mengabaikannya. \n" +
                        "Hingga batas waktu yang telah ditentukan Facebook, yakni hari Kamis tanggal 17 Maret banyak pengguna yang belum mengaktifkan fitur Facebook Protect hingga menyebabkan akun mereka dikunci."
            ),
            Berita(R.drawable.instagramm,
                "Diblokir Rusia, Instagram Kehilangan 80 Juta Pengguna",
                "Rusia saat ini telah memblokir akses ke Instagram setelah Meta menyatakan pengguna Facebook dan Instagram untuk menyuarakan aksi kekerasan yang dilakukan Moskow terhadap Ukraina. \n" +
                        "Dampak pemblokiran tersebut, sekitar 80 juta orang Rusia tidak dapat lagi mengakses Instagram. \n" +
                        "Instagram memang memiliki sekitar 80 juta pengguna di Rusia dan data sekitar 80% dari mereka mengikuti akun yang berasal dari luar perbatasannya. \n" +
                        "Instagram telah lama menjadi salah satu aplikasi iPhone terbaik untuk berbagi foto dan video pendek. \n" +
                        "Kenyataan ini menjadikan Instagram salah satu target paling jelas bagi rezim Rusia yang ingin mengontrol narasi secara ketat di tengah perang yang terjadi di Ukraina. Influencer Instagram Rusia pada akhir pekan memberi tahu penggemarnya bahwa mereka harus mengunduh VPN untuk mencoba melewati blok Rusia, sesuatu yang telah menjadi tren yang berkembang sejak invasi ke Ukraina dimulai.\n" +
                        "Langkah tersebut, yang diancam pekan lalu, dikonfirmasi oleh layanan pemantauan internet GlobalCheck dan The Verge. \n" +
                        "Perubahan sementara dalam kebijakan hanya berlaku untuk kasus tertentu, menurut laporan Reuters. \n" +
                        "Diberitakan sebelumnya Meta mengkonfirmasi kepada The Verge bahwa perubahan telah dilakukan. “Sebagai akibat dari invasi Rusia ke Ukraina, untuk sementara kami mengizinkan bentuk ekspresi politik yang biasanya melanggar aturan kami seperti pidato kekerasan seperti 'matikan penjajah Rusia'. Kami masih tidak akan mengizinkan seruan yang kredibel untuk melakukan kekerasan terhadap warga sipil Rusia"
            ),
            Berita(R.drawable.hackeeeer,
                "Hacker Pura-pura Jadi Polisi, Minta Data Pengguna Apple dan Facebook",
                "Apple dan Meta, perusahaan induk Facebook, memberikan data pengguna kepada hacker yang berpura-pura menjadi polisi. Data pengguna yang diberikan termasuk alamat IP, nomor telepon, dan alamat rumah.\n" +
                        "Insiden ini terjadi pada pertengahan tahun 2021. Penegak hukum memang boleh meminta data pengguna dari platform media sosial terkait investigasi kriminal untuk mengetahui siapa pemilik akun yang dicari.\n" +
                        "Permintaan seperti ini biasanya membutuhkan surat panggilan atau surat perintah penggeledahan dari pengadilan. Tapi surat-surat itu tidak dibutuhkan untuk permintaan data yang bersifat darurat dan ditujukan untuk kasus yang melibatkan situasi yang mengancam jiwa.\n" +
                        "Menurut laporan terbaru Krebs on Security permintaan data palsu memang semakin sering terjadi. Biasanya, hacker harus mengakses sistem email kepolisian terlebih dahulu.\n" +
                        "Hacker kemudian membuat surat permintaan data darurat palsu sambil berpura-pura menjadi anggota kepolisian. Menurut Krebs, beberapa hacker bahkan menjual akses untuk email pemerintahan secara online yang ditujukan khusus untuk meminta data pengguna ke media sosial.\n" +
                        "Krebs mengatakan sebagian besar hacker yang melancarkan serangan ini masih berusia remaja. Bahkan menurut laporan Bloomberg, dalang sindikat hacker Lapsus\$ kemungkinan ikut terlibat dalam penipuan jenis ini.\n" +
                        "Tapi deretan serangan yang diluncurkan tahun lalu diyakini dilakukan oleh kelompok kejahatan siber bernama Recursion Team. Meski kelompok itu telah bubar, beberapa anggotanya ada yang bergabung dengan Lapsus\$ menggunakan nama lain.\n" +
                        "Meski tidak secara langsung mengonfirmasi soal data pengguna yang jatuh ke tangan hacker, Apple dan Meta sama-sama menjelaskan cara mereka menangani permintaan data darurat."

            ),
            Berita(R.drawable.metaaaaaaaaa,
                "Meta Batal Wajibkan Booster COVID Buat Karyawan yang Ngantor",
                "Meta (dulu bernama Facebook) memutuskan berhenti bersikeras mewajibkan karyawan yang ke kantor harus booster COVID-19. Sebelumnya, Meta justru meminta karyawannya untuk booster sebelum ke kantor.\n" +
                        "Sejumlah perusahaan teknologi tampaknya mulai merayu pekerjanya untuk kembali ke kantor. Meta, juga Microsoft, secara bertahap membuka kembali kantornya di Amerika Serikat (AS)\n" +
                        "\n" +
                        "\"Kami memperbarui persyaratan kami yang diumumkan awal Maret untuk menyelaraskan dengan panduan CDC, dan sekarang booster COVID-19 tidak lagi diperlukan sebagai persyaratan masuk kantor, meskipun itu sangat disarankan. Sedangkan persyaratan vaksinasi utama (dosis satu dan dua) tetap berlaku,\" kata juru bicara Meta dikutip dari CNBC.\n" +
                        "Perubahan itu terjadi kurang dari tiga bulan setelah raksasa jejaring sosial itu mengumumkan aturan kembali ke kantor. Juru bicara Meta tidak memberikan penjelasan atas perubahan tersebut.\n" +
                        "\n" +
                        "Menurut data New York Times, di California, tempat kantor pusat Meta, sebanyak 71% populasinya telah divaksinasi penuh, dan 35% telah menerima suntikan booster. Data surat kabar itu juga menyebutkan, jumlah kasus COVID-19 di AS telah menurun sejak Januari.\n" +
                        "Berbeda dengan Meta dan Microsoft, perusahaan teknologi lainnya, Apple yang juga berbasis di San Francisco Bay Area California, tetap mengharuskan karyawan menunjukkan bukti bahwa mereka telah menerima suntikan booster"
            ),
            Berita(R.drawable.appberbahaya,
                "Sudah Ditangkap, Geng Hacker Lapsus\$ Masih Bisa Beraksi",
                "Pada minggu lalu, Kepolisian London menahan tujuh remaja yang diduga terkait geng hacker Lapsus\$. Namun kini, mereka kembali beraksi dan mengklaim sukses meretas sejumlah perusahaan, diduga ada data Facebook dan Apple di dalamnya.\n" +
                        "Klaim tersebut disebar geng hacker remaja ini lewat kanal Telegram miliknya, yang mengklaim mencuri data sebesar 70GB dari Globant, sebuah perusahaan pengembang software asal Luksemburg.\n" +
                        "\n" +
                        "Dari screenshot yang disebar di Twitter, terlihat deretan nama folder berisi nama-nama perusahaan besar, seperti DHL, C-Span, dan bank asal Prancis BNP Paribas. Ada juga nama Apple dan Facebook, yang namanya muncul dalam folder \"apple-health-app\".\n" +
                        "Data Apple dan Facebook tersebut tampaknya adalah materi pengembangan software bernama BeHealthy milik Globant. Aplikasi tersebut dikembangkan bersama Apple untuk memantau kebiasaan karyawan terkait kesehatan menggunakan fitur dari Apple Watch.\n" +
                        "Sindikat hacker Lapsus\$ mengaku bertanggung jawab atas peretasan skala besar yang dialami oleh perusahaan teknologi, termasuk Nvidia, Samsung, Ubisoft, Okta, dan Microsoft.\n" +
                        "Identitas pemimpin kelompok Lapsus\$ berhasil terungkap berkat beberapa konsumen yang marah dan membongkar identitasnya lewat doxing. Menurut laporan pakar keamanan siber Brian Krebs, pemimpin sindikat tersebut membeli Doxbin, situs di mana orang-orang bisa mencari informasi pribadi orang lain.\n" +
                        "Tapi pemimpin kelompok hacker itu tidak bisa mengelola situsnya dengan baik. Ia kabarnya menyerahkan kendali situs pada bulan Januari, tapi membocorkan semua data set Doxbin ke Telegram, dan komunitas Doxbin kemudian membalas dengan membocorkan identitasnya."
            )

        )
        val recyclerView = findViewById<RecyclerView>(R.id.rv_berita)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.setHasFixedSize(true)
        recyclerView.adapter = Berita_Apdater(this, beritaList){
            val intent = Intent (this, DetaiBeritaActivity::class.java)
            intent.putExtra(INTENT_PARCELABLE, it)
            startActivity(intent)
        }
    }
}
package com.example.myberita

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView

// isi dari data dedail berita / untuk menampilakan detail berita
class DetaiBeritaActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detai_berita)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val berita = intent.getParcelableExtra<Berita>(MainActivity.INTENT_PARCELABLE)

        val imgBerita = findViewById<ImageView>(R.id.img_berita)
        val nameBerita = findViewById<TextView>(R.id.Judul_berita)
        val isiBerita = findViewById<TextView>(R.id.isi_berita)

        imgBerita.setImageResource(berita?.imgBerita!!)
        nameBerita.text = berita.nameBerita
        isiBerita.text = berita.isiBerita
    }
// untuk menampikan butom kembali ke berita
    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}
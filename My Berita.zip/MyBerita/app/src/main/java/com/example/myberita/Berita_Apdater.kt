package com.example.myberita

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class Berita_Apdater(private val context: Context, private val berita: List<Berita>, val listener: (Berita) -> Unit)
    : RecyclerView.Adapter<Berita_Apdater.BeritaViewHolder>() {

    class BeritaViewHolder(view: View): RecyclerView.ViewHolder(view) {
// untuk inialisai yang ada di data berita
        val imgBerita = view.findViewById<ImageView>(R.id.img_item_photo)
        val nameBerita = view.findViewById<TextView>(R.id.tv_item_name)
        val isiBerita = view.findViewById<TextView>(R.id.tv_item_description)

        fun bindViiew(berita: Berita, listener: (Berita) -> Unit) {
            imgBerita.setImageResource(berita.imgBerita)
            nameBerita.text = berita.nameBerita
            isiBerita.text = berita.isiBerita
            itemView.setOnClickListener {
                listener(berita)}
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BeritaViewHolder {
        return BeritaViewHolder(
            LayoutInflater.from(context).inflate(R.layout.item_berita, parent, false)
        // Menampilkan layout
        )
    }

    override fun onBindViewHolder(holder: BeritaViewHolder, position: Int) {
        holder.bindViiew(berita[position], listener)
    }

    override fun getItemCount(): Int = berita.size
    }

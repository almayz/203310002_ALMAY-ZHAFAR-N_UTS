package com.example.myberita

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Berita(
    val imgBerita: Int, //untuk menampung data foto
    val nameBerita: String, // untuk menampung data nama berita
    val isiBerita: String, // untuk menampung data isi dari berita
) : Parcelable
